INSERT INTO `releasemessage` (`Id`, `Message`)
VALUES
	(10, 'someAppId+default+application');
INSERT INTO `releasemessage` (`Id`, `Message`)
VALUES
	(20, 'somePublicAppId+default+somePublicNamespace');
